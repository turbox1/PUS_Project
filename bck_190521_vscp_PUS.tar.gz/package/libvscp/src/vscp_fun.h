#ifndef VSCP_FUN
#define VSCP_FUN

#include <stdio.h>
#include "vscp_frame.h"

void print_vscp_frame(const struct vscp_frame *vf);

#endif //VSCP_FUN
