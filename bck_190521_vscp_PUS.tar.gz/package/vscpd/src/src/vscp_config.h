#ifndef VSCP_CONFIG_H
#define VSCP_CONFIG_H

#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

//----------------------- define -------------------------
#define DLE 0x10
#define STX 0x02
#define ETX 0x03
#define BUF_SIZE 16
#define PORT 9999
#define NODE_NUM 255
#define TIMEOUT_HEARTBEAT 2

//---------------------- typedef -------------------------
typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;


//------------------- file_descryptors --------------------
FILE* eeprom_fd;
int serial_fd;
int net_fd;


//------------------- global_variable ---------------------
struct sockaddr_in saddr;
socklen_t saddr_len;
uint8_t active_node;
uint8_t node_list[NODE_NUM];

uint8_t node_unit[NODE_NUM];
short node_temperature[NODE_NUM];
short node_humidity[NODE_NUM];
uint8_t node_light[NODE_NUM];

uint8_t len;
uint8_t buf[BUF_SIZE];
pthread_mutex_t serial_mutex = PTHREAD_MUTEX_INITIALIZER;


//-------------------- eeprom_map -------------------------
#define EEPROM_CRC              0x00
#define EEPROM_NICKNAME         0x01
#define EEPROM_MAJOR_VERSION    0x02
#define EEPROM_MINOR_VERSION    0x03
#define EEPROM_SUBMINOR_VERSION 0x04
#define EEPROM_CTRL_BYTE        0x05
#define EEPROM_ZONE             0x06
#define EEPROM_SUBZONE          0x07
#define EEPROM_GUID             0x08
#define EEPROM_USER_ID			0x0D
#define EEPROM_MANUFACTURER		0x12
#define EEPROM_APP_REGISTER		0x1A

#endif
