#ifndef VSCP_DM_H
#define VSCP_DM_H



void get_decision();


void start_action(id);

#endif
